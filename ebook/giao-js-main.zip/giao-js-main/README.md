## giao.js

A Mini Javascript Interpreter。

### Example

[Example](./example/index.html)

### Article

[Article](./Article.md)

### Related

[bramblex/jsjs](https://github.com/bramblex/jsjs)

[Build a JS Interpreter in JavaScript Using Acorn as a Parser](https://blog.bitsrc.io/build-a-js-interpreter-in-javascript-using-acorn-as-a-parser-5487bb53390c)

### License

The [MIT License](./LICENSE)
